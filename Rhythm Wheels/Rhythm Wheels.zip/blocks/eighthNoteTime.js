(function () {
    return function (sound, time) {
		return eighthNoteTime = (60 / this.getTempo()) / 2;;
	};
}());
//# sourceURL=eighthNoteTime.js