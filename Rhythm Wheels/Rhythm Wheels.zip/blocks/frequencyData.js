(function () {
    return function () {
		return new List(frequencyDataArray);
	};
}());


//# sourceURL=playAtTime.js