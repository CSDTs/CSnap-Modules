(function () {
    return function () {
		return 0.5;
	};
}());

//# sourceURL=halfBeat.js