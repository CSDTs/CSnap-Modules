(function () {
    return function () {
	return 1.0;
	};
}());

//# sourceURL=fullBeat.js