(function () {
    return function (e) {
        var sound = this.costume.name;
		this.playSoundTime(sound, 0);
	};
}());


//# sourceURL=playAtTime.js