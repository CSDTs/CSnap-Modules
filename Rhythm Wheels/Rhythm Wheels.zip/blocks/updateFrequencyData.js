(function () {
    return function () {
		analyser.getByteFrequencyData(frequencyDataArray);
	};
}());


//# sourceURL=playAtTime.js