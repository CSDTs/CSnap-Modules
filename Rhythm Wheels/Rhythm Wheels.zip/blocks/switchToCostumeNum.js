(function () {
    return function (num) {
		this.doSwitchToCostume(this.costumes.at(num).name)
	};
}());


//# sourceURL=playAtTime.js