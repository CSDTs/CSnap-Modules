(function () {
    return function (sound, list) {
		list.add(sound)
	};
}());


//# sourceURL=addSoundToList.js