(function () {
    return function (sound, list) {
		this.doAddToList(sound, list)
	};
}());


//# sourceURL=addSoundToList.js