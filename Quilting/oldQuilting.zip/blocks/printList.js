(function () {
    	return function (list) {
    		function distanceBetween(r1, a1, r2, a2) {
    			var x1 = r1*Math.cos(a1 * Math.PI / 180.0);
    			var x2 = r2*Math.cos(a2 * Math.PI / 180.0);
    			var y1 = r1*Math.sin(a1 * Math.PI / 180.0);
    			var y2 = r2*Math.sin(a2 * Math.PI / 180.0);
    			var arg = Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2);
    			var distance = Math.pow(arg, 0.5);
    			return distance;
    		}

    		function simplifyPoints(radii, angles, min_distance) {
				var valid_points = [ [ ], [ ] ];

				for (i = 0; i < radii.length; i++) {

					var point_is_valid = true;

					for (j = 0; j < radii.length; j++) {

						var distance = distanceBetween(radii[i], angles[i], radii[j], angles[j]); 

						if (distance < min_distance && i != j) {
							point_is_valid = false;
						}
					}

					if (point_is_valid) {
						valid_points[0].push(radii[i]);
						valid_points[1].push(angles[i]);
					}
				}

				return valid_points;			    			
    		}

    		function findDuplicates(valid_points) {
    			var duplicates = [];
    			var radii = valid_points[0];
    			var angles = valid_points[1];

    			for (i = 0; i < radii.length; i++) {

    				for (j = 0; j < angles.length; j++) {

    					if (radii[i] == radii[j] && angles[i] == angles[j] && i != j) {
    						duplicates.push(i);
    					}
    				}
    			}

    			return duplicates;
    		}

    		function writeToWindow(valid_points, duplicates) {

    			var wnd = window.open("");

    			for (i = 0; i < radii.length; i++) {

    				var is_duplicate = false;

    				for (j = 0; j < duplicates.length; j++) {

    					if (i == duplicates[j]) {

    						is_duplicate = true;
    					}
    				}

    				if(!(is_duplicate)) {

    					wnd.document.write(radii[i] + "," + angles[i]);
    					if (i != radii.length - 1) {

    						wnd.document.write("<br>");
    					}
    				}
    			}
    		}

    		
    		var data = list.asText();
    		var radii = [];
    		var angles = [];
    		var is_radius = true;
    		/*for (i  = 0; i < data.length; i++) {
    			if (data[i] != "_" && data[i] != ",") {
	    			if(is_radius) {
	    				radii.push(data[i]);
	    				is_radius = false;
	    			} else {
	    				angles.push(data[i]);
	    				is_radius = true;
	    			}
	    		}
    		}*/

    		//var valid_data = simplifyPoints(radii, angles, 0.2);
    		//var duplicates = findDuplicates(valid_data);
    		//writeToWindow(valid_data, duplicates);

    	};
}());
