var flippedY = false
var flippedX = false
var originalContent
var ID