(function () {
    return function () {
        return this._3DRotationY;
    };
}());


 //# sourceURL=_3DRotationY.js