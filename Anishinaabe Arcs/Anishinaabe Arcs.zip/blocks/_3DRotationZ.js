(function () {
    return function () {
        return this._3DRotationZ;
    };
}());


 //# sourceURL=_3DRotationZ.js