(function () {
    return function () {
        return this._3DRotationX;
    };
}());


 //# sourceURL=_3DRotationX.js