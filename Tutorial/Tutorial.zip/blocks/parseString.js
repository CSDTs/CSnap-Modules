(function () {
   return function (aString, parser) {
	   return aString.split(parser);
   };
}());
