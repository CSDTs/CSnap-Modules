(function () {
   return function () {
      return window.coordinateScale;
   };
}());
