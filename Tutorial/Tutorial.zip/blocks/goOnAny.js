(function () {
    return function () {
    };
}());


//# sourceURL=goOnAny.js
