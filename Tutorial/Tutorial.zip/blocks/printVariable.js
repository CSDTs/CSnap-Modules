(function () {
    return function (list) {
            window.open('data:text/'+ 'plain,' + list.asText());
    };
}());


 //# sourceURL=torus.js