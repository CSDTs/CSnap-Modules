(function () {
   return function (num) {
      window.coordinateScale = num
   };
}());
