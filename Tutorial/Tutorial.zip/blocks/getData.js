(function () {
   return function () {
		return window.data;
   };
}());
