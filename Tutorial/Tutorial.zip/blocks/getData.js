(function () {
   return function () {
		return data;
   };
}());
