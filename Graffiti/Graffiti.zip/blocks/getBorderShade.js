(function () {
	return function () {
		return this.borderColor.hsv()[2] * 100;
	};
}());

//# getShade=code.js