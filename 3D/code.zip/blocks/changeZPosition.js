(function () {
   return function (delta) {
      this.setZPosition(this.zPosition + (+delta || 0));
};}());
