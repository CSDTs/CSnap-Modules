(function () {
   return function () {
      return this.zPosition;
};
}());
